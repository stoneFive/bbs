package com.zx.util.exception;

public class AuthorizationException extends Exception {

}
