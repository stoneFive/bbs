package com.zx.util;

/**
 * Created by Administrator on 2014/10/19.
 */
public final class Constant {

    public static final String SESSION_AUTH_CODE = "session_auth_code";
    
    public static final String SESSION_USER_NAME = "user_name";
    public static final String SESSION_USER = "user_info";

    public static final String TASK_PATH ="c:/taskdir";
    
    public static final String USER_TYPE ="userType";
    
    public static final String USER_TOKEN ="token";
}
