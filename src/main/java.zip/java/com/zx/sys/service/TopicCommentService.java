package com.zx.sys.service;

import com.zx.entity.topic.TopicComment;

/**
 * Created by lance
 * on 2016/12/25.
 * 评论
 */
public interface TopicCommentService extends  BaseService<TopicComment,Long> {
}
