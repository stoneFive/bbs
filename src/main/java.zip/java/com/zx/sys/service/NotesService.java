package com.zx.sys.service;

import com.zx.entity.model.News;
import com.zx.entity.model.Notes;

/**
 * Created by lance
 * on 2017/4/15.
 */
public interface NotesService extends BaseService<Notes,Long>{
}
