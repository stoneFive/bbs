package com.zx.sys.service;


import com.zx.entity.system.Permission;

public interface PermissionService extends BaseService<Permission, Long> {

}
