package com.zx.sys.service;

import com.zx.entity.topic.TopicReply;
import com.zx.sys.service.BaseService;

/**
 * Created by lance
 * on 2016/12/25.
 */
public interface TopicReplyService extends BaseService<TopicReply,Long> {
}
