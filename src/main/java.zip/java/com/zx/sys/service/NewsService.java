package com.zx.sys.service;

import com.zx.entity.model.News;
import com.zx.sys.repository.NewsRepository;
import com.zx.sys.service.impl.BaseServiceImpl;

/**
 * Created by lance
 * on 2017/4/15.
 */
public interface NewsService extends BaseService<News,Long>{
}
