package com.zx.sys.repository;

import com.zx.entity.topic.Topic;
import com.zx.sys.service.BaseService;

/**
 * Created by lance
 * on 2016/12/25.
 */
public interface TopicRepository extends BaseRepository<Topic,Long>{
}
