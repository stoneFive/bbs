package com.zx.sys.repository;

import com.zx.entity.topic.TopicReply;

/**
 * Created by lance
 * on 2016/12/25.
 */
public interface TopicReplyRepository extends BaseRepository<TopicReply ,Long> {
}
