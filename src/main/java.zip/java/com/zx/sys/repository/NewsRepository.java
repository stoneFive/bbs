package com.zx.sys.repository;

import com.zx.entity.model.News;

/**
 * Created by lance
 * on 2017/4/15.
 */
public interface NewsRepository extends BaseRepository<News,Long>{
}
