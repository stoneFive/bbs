package com.zx.sys.repository;

import com.zx.entity.model.News;
import com.zx.entity.model.Trends;

/**
 * Created by lance
 * on 2017/4/15.
 */
public interface TrendsRepository extends BaseRepository<Trends,Long>{
}
