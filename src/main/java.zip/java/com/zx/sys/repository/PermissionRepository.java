package com.zx.sys.repository;


import com.zx.entity.system.Permission;

public interface PermissionRepository extends BaseRepository<Permission,Long> {

}
