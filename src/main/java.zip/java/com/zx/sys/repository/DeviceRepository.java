package com.zx.sys.repository;

import com.zx.entity.model.Device;

/**
 * Created by lance
 * on 2017/4/8.
 */
public interface DeviceRepository extends BaseRepository<Device,Long> {
}
